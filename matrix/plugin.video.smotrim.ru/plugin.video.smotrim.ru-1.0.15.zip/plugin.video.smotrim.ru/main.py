# coding=utf-8
# Module: main
# Author: Alex Bratchik
# Created on: 03.04.2021
# License: GPL v.3 https://www.gnu.org/copyleft/gpl.html
"""
Video plugin for Smotrim.ru portal
"""
import os
import sys
from stat import S_ISREG, ST_CTIME, ST_MODE
import re
import json
from urllib.request import urlopen
from urllib.parse import urlencode, parse_qsl

import xbmc
import xbmcgui
import xbmcaddon
import xbmcplugin

# Main addon class
class Smotrim():

    def __init__(self):
        self.id = "plugin.video.smotrim.ru"
        self.addon = xbmcaddon.Addon(self.id)
        self.path = self.addon.getAddonInfo('path')
        self.mediapath = os.path.join(self.path, "resources/media")
        self.data_path = self.create_folder(os.path.join(xbmc.translatePath(self.addon.getAddonInfo('profile')),
                                                         'data'))
        self.history_folder = self.create_folder(os.path.join(self.data_path, 'history'))

        self.url = sys.argv[0]
        self.handle = int(sys.argv[1])
        self.params = {}

        self.inext = os.path.join(self.mediapath, 'next.png')
        self.ihistory = os.path.join(self.mediapath, 'history.png')
        self.iarticles = os.path.join(self.mediapath, 'news.png')
        self.ihome = os.path.join(self.mediapath, 'home.png')
        self.background = os.path.join(self.mediapath, 'background.jpg')

        self.api_url = "https://api.smotrim.ru/api/v1"

        self.search_text = ""

        self.language = self.addon.getLocalizedString

        # to save current context
        self.context = "home"
        self.context_title = self.language(30300)

        # list to hold current listing
        self.categories = []

        # list of brands
        self.brands = {}
        # list of episodes
        self.episodes = {}
        # list of articles
        self.articles = {}

        with open(os.path.join(self.path, "resources/data/tags.json"), "r+") as f:
            self.TAGS = json.load(f)

    def main(self):
        xbmc.log("Addon: %s" % self.id, xbmc.LOGDEBUG)
        xbmc.log("Handle: %d" % self.handle, xbmc.LOGDEBUG)

        params_ = sys.argv[2]
        xbmc.log("Params: %s" % params_, xbmc.LOGDEBUG)
        self.params = dict(parse_qsl(params_[1:]))

        self.context = self.params['action'] if 'action' in self.params else "home"

        xbmc.log("Action: %s" % self.context, xbmc.LOGDEBUG)

        if self.params:
            if self.params['action'] == 'play':
                self.play()
            else:
                getattr(self, self.context)()
                self.get_categories()
                self.menu()
        else:
            # default context is home
            self.get_categories()
            self.menu()

    def menu(self):

        xbmcplugin.setPluginCategory(self.handle, self.context_title)

        if self.context == "home":
            xbmcplugin.setContent(self.handle, "files")
        else:
            xbmcplugin.setContent(self.handle, self.params['content'] if "content" in self.params else "videos")

        # Iterate through categories
        for category in self.categories:
            # Create a list item with a text label and a thumbnail image.
            list_item = xbmcgui.ListItem(label=category['label'])

            url = category['url']

            is_folder = category['is_folder']
            list_item.setProperty('IsPlayable', str(category['is_playable']).lower())

            if 'info' in category:
                for info in category['info']:
                    list_item.setInfo('video', {info: category['info'][info]})
                    if info == 'mediatype':
                        list_item.addContextMenuItems([(self.language(30000),
                                                        "XBMC.Action(%s)" % ("Play"
                                                                             if category['info']['mediatype'] == "news"
                                                                             else "Info")
                                                        ), ])

            if 'art' in category:
                for art in category['art']:
                    list_item.setArt({art: category['art'][art]})

            xbmcplugin.addDirectoryItem(self.handle, url, list_item, is_folder)

        # Finish creating a virtual folder.
        xbmcplugin.endOfDirectory(self.handle)

    def get_url(self, baseurl=None, **kwargs):
        baseurl_ = baseurl if baseurl else self.url
        url = '{}?{}'.format(baseurl_, urlencode(kwargs))
        return url

    # get series
    def get_episodes(self):

        brand = self.params['brands']

        offset = self.params['offset'] if 'offset' in self.params else 0
        limit = self.get_limit_setting()

        xbmc.log("items per page: %s" % limit, xbmc.LOGDEBUG)

        if brand:
            xbmc.log("Load episodes for brand [ %s ] " % brand, xbmc.LOGDEBUG)

            self.episodes = self.get(self.get_url(self.api_url + '/episodes',
                                                  brands=brand,
                                                  limit=limit,
                                                  offset=offset))

            if 'data' in self.episodes:
                self.context_title = self.episodes['data'][0]['brandTitle'] \
                    if len(self.episodes) > 0 else self.language(30040)

    # get artiles
    def get_articles(self):

        offset = self.params['offset'] if 'offset' in self.params else 0
        limit = self.get_limit_setting()

        xbmc.log("items per page: %s" % limit, xbmc.LOGDEBUG)

        self.articles = self.get(self.get_url(self.api_url + '/articles',
                                              limit=limit,
                                              offset=offset))

        self.context_title = self.language(30301)

    # Search by tag
    def search_by_tag(self):

        tag = int(self.params['tags']) if 'tags' in self.params else None
        limit, offset = self.get_limit_offset()

        tag_dict = self.search_tag_by_id(self.TAGS, tag)

        self.context_title = self.language(int(tag_dict['titleId']))

        if 'tags' in tag_dict:
            pass
        else:
            self.search_by_url(self.get_url(self.api_url + '/brands',
                                            tags=tag,
                                            limit=limit,
                                            offset=offset) if tag else None)

    # Search by text
    def search(self):
        self.context_title = self.language(30010)
        self.search_text = self.params['search'] if 'search' in self.params else self.get_user_input()
        limit, offset = self.get_limit_offset()
        self.search_by_url(self.get_url(self.api_url + '/brands',
                                        search=self.search_text,
                                        limit=limit,
                                        offset=offset) if self.search_text else None)

    def search_by_url(self, url):
        if url:
            xbmc.log("Load search results for url [ %s ] " % url, xbmc.LOGDEBUG)
            self.brands = self.get(url)
        else:
            self.context = "home"

    def get_limit_offset(self):
        offset = self.params['offset'] if 'offset' in self.params else 0
        limit = (self.addon.getSettingInt('itemsperpage') + 1) * 10
        return limit, offset

    def get_limit_offset_pages(self, resp_dict):
        if 'pagination' in resp_dict:
            offset = resp_dict['pagination']['offset'] if 'pagination' in resp_dict else 0
            limit = resp_dict['pagination']['limit'] if 'pagination' in resp_dict else 0
            pages = resp_dict['pagination']['pages'] if 'pagination' in resp_dict else 0
            return limit, offset, pages
        else:
            return 0, 0, 0

    # Get categories for the current context
    def get_categories(self):

        xbmc.log("self.URL is %s" % self.url, xbmc.LOGDEBUG)

        if self.context == 'home':
            self.add_search()
            self.add_articles()
            self.add_searches_by_tags(self.TAGS)

            if self.addon.getSettingBool("addhistory"):
                self.add_history()

        offset = 0
        pages = 0
        url = ""

        if self.context == "search":
            if 'data' in self.brands:
                limit, offset, pages = self.get_limit_offset_pages(self.brands)
                for brand in self.brands['data']:
                    self.categories.append(self.create_brand_dict(brand))
                url = self.get_url(self.url, action=self.context,
                                   search=self.search_text,
                                   offset=offset + 1,
                                   limit=limit,
                                   url=self.url)
        elif self.context == "search_by_tag":
            if 'data' in self.brands:
                limit, offset, pages = self.get_limit_offset_pages(self.brands)
                for brand in self.brands['data']:
                    self.categories.append(self.create_brand_dict(brand))
                url = self.get_url(self.url, action=self.context,
                                   tags=self.params['tags'],
                                   offset=offset + 1,
                                   limit=limit,
                                   url=self.url)
            else:
                tag_dict = self.search_tag_by_id(self.TAGS, int(self.params['tags']))
                if 'tags' in tag_dict:
                    self.add_searches_by_tags(tag_dict['tags'])

        elif self.context == "get_episodes":
            if 'data' in self.episodes:
                limit, offset, pages = self.get_limit_offset_pages(self.episodes)
                for ep in self.episodes['data']:
                    if ep['countVideos'] > 0 or ep['countAudios'] > 0:
                        self.categories.append(self.create_episode_dict(ep))
                url = self.get_url(self.url, action=self.context,
                                   brands=self.params['brands'],
                                   offset=offset + 1,
                                   limit=limit,
                                   url=self.url)
        elif self.context == "get_articles":
            if 'data' in self.articles:
                limit, offset, pages = self.get_limit_offset_pages(self.articles)
                for ar in self.articles['data']:
                    self.categories.append(self.create_article_dict(ar))
            url = self.get_url(self.url, action=self.context,
                               offset=offset + 1,
                               limit=limit,
                               url=self.url)
        else:
            if 'data' in self.brands:
                for brand in self.brands['data']:
                    self.categories.append(self.create_brand_dict(brand))

        if offset < pages - 1 and pages > 1:
            self.categories.append({'id': "home",
                                    'label': "[COLOR=FF00FF00][B]%s[/B][/COLOR]" % self.language(30020),
                                    'is_folder': True,
                                    'is_playable': False,
                                    'url': self.url,
                                    'info': {'plot': self.language(30021)},
                                    'art': {'icon': self.ihome}
                                    })
            self.categories.append({'id': "forward",
                                    'label': "[COLOR=FF00FF00][B]%s[/B][/COLOR]" % self.language(30030),
                                    'is_folder': True,
                                    'is_playable': False,
                                    'url': url,
                                    'info': {'plot': self.language(30031) % (offset + 1, pages)},
                                    'art': {'icon': self.inext}
                                    })

    # Add Search menu to categories
    def add_search(self):
        self.categories.append({'id': "search",
                                'label': "[COLOR=FF00FF00][B]%s[/B][/COLOR]" % self.language(30010),
                                'is_folder': True,
                                'is_playable': False,
                                'url': self.get_url(self.url, action='search', url=self.url),
                                'info': {'plot': self.language(30011)},
                                'art': {'icon': os.path.join(self.mediapath, "search.png"),
                                        'fanart': self.background}
                                })

    def add_search_by_tag(self, tag, tagname, taginfo=None, tagicon="DefaultAddonsSearch.png", content="videos"):
        self.categories.append({'id': "tag%s" % str(tag),
                                'label': "[B]%s[/B]" % tagname,
                                'is_folder': True,
                                'is_playable': False,
                                'url': self.get_url(self.url,
                                                    action='search_by_tag',
                                                    tags=tag,
                                                    content=content,
                                                    url=self.url),
                                'info': {'plot': taginfo if taginfo else tagname},
                                'art': {'icon': tagicon,
                                        'fanart': self.background}
                                })

    def add_searches_by_tags(self, tags):
        for tag in tags:
            self.add_search_by_tag(tag['tag'],
                                   tagname=self.language(int(tag['titleId'])),
                                   taginfo=self.language(int(tag['titleId'])),
                                   tagicon=os.path.join(self.mediapath, tag['icon']) if 'icon' in tag
                                   else "DefaultAddonsSearch.png",
                                   content=tag['content'] if 'content' in tag else "videos")

    def history(self):
        self.context_title = self.language(30050)
        limit = self.get_limit_setting()
        data = (os.path.join(self.history_folder, fn) for fn in os.listdir(self.history_folder))
        data = ((os.stat(path), path) for path in data)

        data = ((stat[ST_CTIME], path)
                for stat, path in data if S_ISREG(stat[ST_MODE]))
        self.brands = {'data': [], }
        for cdate, path in sorted(data, reverse=True):
            with open(path, 'r+') as f:
                xbmc.log("history len = %s" % len(self.brands['data']), xbmc.LOGDEBUG)
                if len(self.brands['data']) < limit:
                    self.brands['data'].append(json.load(f))
                else:
                    # autocleanup
                    os.remove(path)

    def save_brand_to_history(self, brand):
        with open(os.path.join(self.history_folder, "brand_%s.json" % brand['id']), 'w+') as f:
            json.dump(brand, f)

    def add_articles(self):
        self.categories.append({'id': "articles",
                                'label': "[COLOR=FF00FF00][B]%s[/B][/COLOR]" % self.language(30301),
                                'is_folder': True,
                                'is_playable': False,
                                'url': self.get_url(self.url, action='get_articles', url=self.url),
                                'info': {'plot': self.language(30301)},
                                'art': {'icon': self.iarticles,
                                        'fanart': self.background}
                                })

    def add_history(self):
        self.categories.append({'id': "history",
                                'label': "[COLOR=FF00FF00][B]%s[/B][/COLOR]" % self.language(30050),
                                'is_folder': True,
                                'is_playable': False,
                                'url': self.get_url(self.url, action='history', url=self.url),
                                'info': {'plot': self.language(30051)},
                                'art': {'icon': self.ihistory,
                                        'fanart': self.background}
                                })

    def create_article_dict(self, article):
        return {'id': article['id'],
                'is_folder': False,
                'is_playable': True if article['videos'] else False,
                'label': "[COLOR=FF00FFFF]%s[/COLOR] %s" % (self.language(30302), article['title'])
                if article['videos'] else article['title'],
                'url': self.get_url(self.url,
                                    action="play",
                                    articles=article['id'],
                                    videos=article['videos'][0]['id'],
                                    url=self.url) if article['videos'] else
                self.get_url(self.url,
                             action="play",
                             articles=article['id'],
                             url=self.url),
                'info': {'title': article['title'],
                         'mediatype': "video" if article['videos'] else "news",
                         'plot': self.cleanhtml(article['body']),
                         'plotoutline': article['anons'],
                         'dateadded': article['datePub']
                         },
                'art': {'fanart': self.get_pic_from_plist(article['pictures'], 'hd'),
                        'icon': self.get_pic_from_plist(article['pictures'], 'lw'),
                        'thumb': self.get_pic_from_plist(article['pictures'], 'lw'),
                        'poster': self.get_pic_from_plist(article['pictures'], 'it')
                        }
                }

    def create_brand_dict(self, brand):
        is_folder = brand['hasManySeries'] or \
                    brand['countVideos'] > 1 or \
                    brand['countAudioEpisodes'] > 1
        is_music_folder = is_folder and brand['countAudioEpisodes'] == brand['countVideos']
        return {'id': brand['id'],
                'is_folder': is_folder,
                'is_playable': not is_folder,
                'label': "[B]%s[/B]" % brand['title'] if is_folder else brand['title'],
                'url': self.get_url(self.url,
                                    action="get_episodes",
                                    content="musicvideos" if is_music_folder else "episodes",
                                    brands=brand['id'],
                                    url=self.url) if is_folder
                else self.get_url(self.url,
                                  action="play",
                                  brands=brand['id'],
                                  url=self.url),

                'info': {'title': brand['title'],
                         'genre': brand['genre'],
                         'mediatype': "tvshow" if is_folder else "movie",
                         'year': brand['productionYearStart'],
                         'plot': self.cleanhtml(brand['body']),
                         'plotoutline': brand['anons'],
                         'rating': brand['rank'],
                         'dateadded': brand['dateRec']
                         },
                'art': {'thumb': "%s/pictures/%s/lw/redirect" % (self.api_url, brand['picId']),
                        'icon': "%s/pictures/%s/lw/redirect" % (self.api_url, brand['picId']),
                        'fanart': "%s/pictures/%s/hd/redirect" % (self.api_url, brand['picId']),
                        'poster': "%s/pictures/%s/vhdr/redirect" % (self.api_url, brand['picId'])
                        }
                }

    def create_episode_dict(self, ep):
        is_audio = ep['countAudios'] > 0
        return {'id': ep['id'],
                'label': ep['combinedTitle'],
                'is_folder': False,
                'is_playable': True,
                'url': self.get_url(self.url,
                                    action="play",
                                    brands=ep['brandId'],
                                    episodes=ep['id'],
                                    is_audio=is_audio,
                                    url=self.url),
                'info': {'title': ep['combinedTitle'],
                         'tvshowtitle': ep['brandTitle'],
                         'mediatype': "episode",
                         'plot': self.cleanhtml(ep['body']),
                         'plotoutline': ep['anons'],
                         'episode': ep['series'],
                         'sortepisode': ep['series'],
                         'dateadded': ep['dateRec']
                         } if not is_audio else
                {'mediatype': "music",
                 'title': ep['title'],
                 'plot': "%s[CR]%s" % (ep['title'], ep['anons'])},
                'art': {'fanart': self.get_pic_from_plist(ep['pictures'], 'hd'),
                        'icon': self.get_pic_from_plist(ep['pictures'], 'lw'),
                        'thumb': self.get_pic_from_plist(ep['pictures'], 'lw'),
                        'poster': self.get_pic_from_plist(ep['pictures'], 'vhdr')
                        }
                }

    def get_user_input(self):
        kbd = xbmc.Keyboard()
        kbd.setDefault('')
        kbd.setHeading(self.language(30010))
        kbd.doModal()
        keyword = None

        if kbd.isConfirmed():
            keyword = kbd.getText()

        return keyword

    def play(self):

        try:
            if 'episodes' in self.params:
                if json.loads(self.params['is_audio'].lower()):
                    audios = self.get(
                        self.get_url(self.api_url + '/audios', episodes=self.params['episodes']))
                    spath = audios['data'][0]['sources']['mp3']
                else:
                    videos = self.get(
                        self.get_url(self.api_url + '/videos', episodes=self.params['episodes']))
                    spath = videos['data'][0]['sources']['m3u8']['auto']
            elif 'brands' in self.params:
                videos = self.get(self.get_url(self.api_url + '/videos', brands=self.params['brands']))
                spath = videos['data'][0]['sources']['m3u8']['auto']
            elif 'articles' in self.params:
                articles = self.get(self.get_url(self.api_url + '/articles/' + self.params['articles']))
                if articles['data']['videos']:
                    spath = articles['data']['videos'][0]['sources']['m3u8']['auto']
                else:
                    xbmcgui.Dialog().textviewer(articles['data']['title'], self.cleanhtml(articles['data']['body']))
                    return
            elif 'videos' in self.params:
                videos = self.get(self.api_url + '/videos/' + self.params['videos'])
                spath = videos['data']['sources']['m3u8']['auto']
            else:
                raise ValueError(self.language(30060))

            if self.addon.getSettingBool("addhistory") and 'brands' in self.params:
                resp = self.get(self.api_url + '/brands/' + self.params['brands'])
                self.save_brand_to_history(resp['data'])
            play_item = xbmcgui.ListItem(path=spath)
            if '.m3u8' in spath:
                play_item.setProperty('inputstreamaddon', 'inputstream.adaptive')
                play_item.setProperty('inputstream.adaptive.manifest_type', 'hls')
                play_item.setProperty('inputstream.adaptive.play_timeshift_buffer', 'true')
            xbmcplugin.setResolvedUrl(self.handle, True, listitem=play_item)
        except ValueError:
            self.show_error_message(self.language(30060))

    def cleanhtml(self, raw_html):
        try:
            cleanr = re.compile('<.*?>|&([a-z0-9]+|#[0-9]{1,6}|#x[0-9a-f]{1,6});')
            cleantext = re.sub(cleanr, '', raw_html)
            return cleantext
        except:
            return raw_html

    def get_pic_from_plist(self, plist, res):
        try:
            ep_pics = plist[0]['sizes']
            pic = next(p for p in ep_pics if p['preset'] == res)
            return pic['url']
        except:
            return ""

    def search_tag_by_id(self, tags, tag):
        for t in tags:
            if t['tag'] == tag:
                return t
            if 'tags' in t:
                ct = self.search_tag_by_id(t['tags'], tag)
                if ct:
                    return ct
        return {}

    # *** Add-on helpers

    def get(self, url):
        response = urlopen(url)
        return json.load(response)

    def create_folder(self, folder):
        if not (os.path.exists(folder) and os.path.isdir(folder)):
            os.makedirs(folder)
        return folder

    def error(self, message):
        xbmc.log("%s ERROR: %s" % (self.id, message), xbmc.LOGDEBUG)

    def show_error_message(self, msg):
        xbmc.log(msg, xbmc.LOGDEBUG)
        xbmc.executebuiltin("XBMC.Notification(%s,%s, %s)" % ("ERROR", msg, str(3 * 1000)))

    def get_limit_setting(self):
        return (self.addon.getSettingInt('itemsperpage') + 1) * 10


if __name__ == '__main__':
    Smotrim = Smotrim()
    Smotrim.main()
