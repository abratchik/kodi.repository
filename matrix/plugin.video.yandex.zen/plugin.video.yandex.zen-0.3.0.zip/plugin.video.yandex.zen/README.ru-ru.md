# Дополнение Kodi для Яндекс Дзен
[![en](https://img.shields.io/badge/lang-en-green.svg)](./README.md)
[![ru-ru](https://img.shields.io/badge/lang-ru--ru-red.svg)](./README.ru-ru.md)