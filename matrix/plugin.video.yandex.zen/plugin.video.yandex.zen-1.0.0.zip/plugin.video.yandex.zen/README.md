# KODI Addon for Yandex Zen
[![en](https://img.shields.io/badge/lang-en-red.svg)](./README.md)
[![ru-ru](https://img.shields.io/badge/lang-ru--ru-green.svg)](./README.ru-ru.md)